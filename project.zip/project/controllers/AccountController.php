<?php
require_once __DIR__ . '/../models/UserModel.php';

final class AccountController extends BaseController
{
    private function requireLogin(): array
    {
        $u = $_SESSION['user'] ?? null;
        if (!$u) {
            $this->flash('error', 'Vui lòng đăng nhập');
            $this->redirect('?controller=auth&action=login');
        }
        return $u;
    }

    public function profile(): string
    {
        $u = $this->requireLogin();
        $user = UserModel::findById((int)$u['id']);
        $csrf = $this->csrfToken();
        $active = 'profile';

        return $this->render('account/profile', compact('user','csrf','active'));
    }

    public function updateProfile(): string
    {
        $u = $this->requireLogin();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->checkCsrf();

            $name  = trim($_POST['name'] ?? '');
            $email = trim($_POST['email'] ?? '');

            $error = null;
            if ($name === '' || $email === '') {
                $error = 'Tên và email không được rỗng';
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $error = 'Email không hợp lệ';
            } elseif (UserModel::emailExistsForOther($email, (int)$u['id'])) {
                $error = 'Email đã được sử dụng';
            }

            if ($error) {
                $user = UserModel::findById((int)$u['id']);
                $csrf = $this->csrfToken();
                $active = 'profile';
                return $this->render('account/profile', compact('user','csrf','active','error'));
            }

            UserModel::updateProfile((int)$u['id'], $name, $email);

            $_SESSION['user']['name']  = $name;
            $_SESSION['user']['email'] = $email;

            $this->flash('success', 'Cập nhật thông tin thành công');
            $this->redirect('?controller=account&action=profile');
        }

        $this->redirect('?controller=account&action=profile');
        return '';
    }
    
    public function password(): string
    {
        $this->requireLogin();
        $csrf = $this->csrfToken();
        $active = 'password';
        return $this->render('account/password', compact('csrf','active')); 
    }

    public function changePassword(): string
    {
        $u = $this->requireLogin();
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('?controller=account&action=password');
            return '';
        }
        
        $this->checkCsrf();

        $oldPassword = (string)($_POST['old_password'] ?? '');
        $newPassword = (string)($_POST['new_password'] ?? '');
        $newPassword2 = (string)($_POST['confirm_password'] ?? '');

        $user = UserModel::findById((int)$u['id']); 

        $error = null;

        if (!password_verify($oldPassword, $user['password'] ?? '')) {
            $error = 'Mật khẩu cũ không đúng.';
        } elseif (strlen($newPassword) < 6) {
            $error = 'Mật khẩu mới phải tối thiểu 6 ký tự.';
        } elseif ($newPassword !== $newPassword2) {
            $error = 'Mật khẩu mới và xác nhận không khớp.';
        }

        if ($error) {
            $csrf = $this->csrfToken();
            $active = 'password';
            return $this->render('account/password', compact('csrf', 'active', 'error'));
        }

        UserModel::updatePassword((int)$u['id'], $newPassword);

        $this->flash('success', 'Đổi mật khẩu thành công!');
        $this->redirect('?controller=account&action=password');
        return '';
    }

    /**
     * Trang Sổ địa chỉ
     * URL: index.php?controller=account&action=address
     */
    public function address(): string
    {
        $u = $this->requireLogin();
        
        $addresses = UserModel::getAddresses((int)$u['id']);

        $csrf = $this->csrfToken();
        $active = 'address';
        
        return $this->render('account/address', compact('addresses', 'csrf', 'active'));
    }

    /**
     * Thêm địa chỉ mới
     * URL: POST index.php?controller=account&action=addAddress
     */
    public function addAddress(): string
    {
        $u = $this->requireLogin();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->checkCsrf();

            $address = trim($_POST['full_address'] ?? '');
            $phone = trim($_POST['shipping_phone'] ?? '');
            $isDefault = isset($_POST['is_default']);

            if ($address === '' || $phone === '') {
                $this->flash('error', 'Địa chỉ và số điện thoại không được rỗng.');
            } else {
                UserModel::createAddress((int)$u['id'], $address, $phone, $isDefault);
                $this->flash('success', 'Thêm địa chỉ giao hàng thành công.');
            }
        }
        
        $this->redirect('?controller=account&action=address');
        return '';
    }

    /**
     * Đặt địa chỉ làm mặc định
     * URL: index.php?controller=account&action=setDefaultAddress&id=ADDRESS_ID
     */
    public function setDefaultAddress(int $id): string
    {
        $u = $this->requireLogin();
        
        $address = UserModel::findAddressById($id, (int)$u['id']);
        
        if (!$address) {
            $this->flash('error', 'Địa chỉ không hợp lệ.');
        } else {
            UserModel::setDefaultAddress($id, (int)$u['id']);
            $this->flash('success', 'Đặt địa chỉ mặc định thành công.');
        }

        $this->redirect('?controller=account&action=address');
        return '';
    }

    /**
     * Xóa địa chỉ
     * URL: index.php?controller=account&action=deleteAddress&id=ADDRESS_ID
     */
    public function deleteAddress(int $id): string
    {
        $u = $this->requireLogin();
        
        $deleted = UserModel::deleteAddress($id, (int)$u['id']);

        if ($deleted) {
             $this->flash('success', 'Xóa địa chỉ thành công.');
        } else {
             $this->flash('error', 'Không thể xóa địa chỉ. Địa chỉ không tồn tại hoặc bạn không có quyền.');
        }

        $this->redirect('?controller=account&action=address');
        return '';
    }

    // ================================================================
    // PHẦN MỚI THÊM VÀO: DANH SÁCH YÊU THÍCH (WISHLIST)
    // ================================================================

    /**
     * Trang danh sách yêu thích
     * URL: index.php?controller=account&action=wishlist
     */
    public function wishlist(): string
    {
        $u = $this->requireLogin();

        // Nạp Model Wishlist
        require_once __DIR__ . '/../models/WishlistModel.php';

        // Lấy danh sách
        $books = Wishlist::getWishlist((int)$u['id']);

        $csrf = $this->csrfToken();
        $active = 'wishlist'; // Để highlight menu bên trái

        return $this->render('account/wishlist', compact('books', 'csrf', 'active'));
    }

    /**
     * Xóa khỏi danh sách yêu thích
     * URL: index.php?controller=account&action=removeWishlist&id=...
     */
    public function removeWishlist(): string
    {
        $u = $this->requireLogin();
        $bookId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

        if ($bookId > 0) {
            require_once __DIR__ . '/../models/WishlistModel.php';
            Wishlist::remove((int)$u['id'], $bookId);
            $this->flash('success', 'Đã xóa sản phẩm khỏi danh sách yêu thích');
        }

        $this->redirect('?controller=account&action=wishlist');
        return '';
    }
    public function addWishlist(): void
    {
        // 1. Kiểm tra đăng nhập
        $u = $this->requireLogin();
        
        $bookId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

        if ($bookId > 0) {
            require_once __DIR__ . '/../models/WishlistModel.php';
            
            // 2. Gọi Model để thêm
            Wishlist::add((int)$u['id'], $bookId);
            
            // 3. Thông báo
            $this->flash('success', 'Đã thêm sách vào danh sách yêu thích ❤️');
        }

        // 4. Quay lại trang cũ (để người dùng tiếp tục lướt)
        $backUrl = $_SERVER['HTTP_REFERER'] ?? '?controller=home';
        $this->redirect($backUrl);
    }
    // --- BẮT ĐẦU PHẦN LỊCH SỬ ĐƠN HÀNG ---

    /**
     * Hiển thị danh sách đơn hàng
     * URL: index.php?controller=account&action=orders
     */
    public function orders(): string
    {
        $u = $this->requireLogin();
        require_once __DIR__ . '/../models/OrderModel.php';

        $orders = OrderModel::getHistory((int)$u['id']);
        $active = 'orders'; // Để tô màu menu sidebar

        return $this->render('account/orders', compact('orders', 'active'));
    }

    /**
     * Hiển thị chi tiết đơn hàng
     * URL: index.php?controller=account&action=orderDetail&id=XXX
     */
    public function orderDetail(): string
    {
        $u = $this->requireLogin();
        require_once __DIR__ . '/../models/OrderModel.php';

        $orderId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

        // 1. Lấy thông tin đơn (Header)
        $order = OrderModel::getOrderById($orderId, (int)$u['id']);
        if (!$order) {
            $this->flash('error', 'Không tìm thấy đơn hàng này.');
            $this->redirect('?controller=account&action=orders');
            return '';
        }

        // 2. Lấy danh sách món hàng (Items)
        $items = OrderModel::getOrderItems($orderId);
        $active = 'orders';

        return $this->render('account/order_detail', compact('order', 'items', 'active'));
    }
    
    // --- KẾT THÚC PHẦN LỊCH SỬ ĐƠN HÀNG ---
}